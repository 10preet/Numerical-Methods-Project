function v = vL(s,t,T)
% vL(s,t,T) computes the approx. lower boundary value at (s,t)
% for terminal time T.
global r K
v=0;                                            % For a call option
end